const form = document.getElementById('login-form');

form.addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('username');
    const password = document.getElementById('password');
    const usernameError = document.getElementById('username-error');
    const passwordError = document.getElementById('password-error');

    // Reset previous errors
    usernameError.textContent = '';
    passwordError.textContent = '';

    // Simple validation
    let valid = true;

    if (username.value.trim() === '') {
        usernameError.textContent = 'Username is required';
        username.classList.add('error');
        valid = false;
    } else {
        username.classList.remove('error');
    }

    if (password.value.trim() === '') {
        passwordError.textContent = 'Password is required';
        password.classList.add('error');
        valid = false;
    } else {
        password.classList.remove('error');
    }

    if (valid) {
        // You can add AJAX or other code here to handle form submission.
        alert('Form submitted successfully.');
    }
});